
# SWT Group 6


## Members

| Name                   | Student Number |
|------------------------|----------------|
| Emil Holm Riis         | 202305265      |
| Andreas Gadgaard       | 202306990      |
| Jesper Lund Pedersen   | 202308221      |

#### Link til Repository [HERE](https://gitlab.au.dk/au724429/swt-group6-handin2)

#### Link til Dokumentation [HERE](https://gitlab.au.dk/au724429/swt-group6-handin2/-/tree/main/docs?ref_type=heads)